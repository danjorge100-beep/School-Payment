-- 03_payment_functions.sql : all money logic runs here, in one transaction per call

create or replace function my_role() returns text
language sql stable security definer set search_path = public as $$
  select role from profiles where id = auth.uid() $$;

-- internal: mark payment successful, update the fee, issue receipt (not callable from the browser)
create or replace function apply_payment(p_id uuid, p_teacher uuid) returns void
language plpgsql security definer set search_path = public as $$
declare pay payments; paid numeric; due numeric; tname text;
begin
  select * into pay from payments where id = p_id;
  update student_fees set amount_paid = amount_paid + pay.amount_paid
    where id = pay.student_fee_id returning amount_paid, amount_due into paid, due;
  update student_fees set status = case when paid >= due then 'paid' when paid > 0 then 'partial' else 'unpaid' end
    where id = pay.student_fee_id;
  select pr.full_name into tname from teachers t join profiles pr on pr.id = t.profile_id where t.id = p_teacher;
  update payments set status = 'success', received_by = coalesce(p_teacher, received_by),
    received_by_name = coalesce(tname, received_by_name, 'System') where id = p_id;
  insert into receipts (receipt_number, payment_id) values
    ('RCPT-' || to_char(now(),'YYYYMMDD') || '-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,6)), p_id)
    on conflict (payment_id) do nothing;
end $$;

-- Student pays OR teacher (cashier) receives. Card/online are SIMULATED (about 90% succeed).
-- Student cash = stays pending until a teacher confirms. Teacher cash = always succeeds.
create or replace function process_payment(p_student_fee_id uuid, p_amount numeric, p_method text)
returns json language plpgsql security definer set search_path = public as $$
declare sf student_fees; r text := my_role(); my_student uuid; my_teacher uuid; new_id uuid; ok boolean;
begin
  if r not in ('student','teacher') then raise exception 'Not allowed'; end if;
  if p_method not in ('cash','card','online') then raise exception 'Invalid payment method'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Amount must be greater than 0'; end if;
  select * into sf from student_fees where id = p_student_fee_id;
  if not found then raise exception 'Fee not found'; end if;
  if p_amount > sf.amount_due - sf.amount_paid then raise exception 'Amount exceeds the remaining balance'; end if;
  if r = 'student' then
    select id into my_student from students where profile_id = auth.uid();
    if my_student is distinct from sf.student_id then raise exception 'This is not your fee'; end if;
  else
    select id into my_teacher from teachers where profile_id = auth.uid();
  end if;

  insert into payments (student_fee_id, student_id, amount_paid, payment_method, status, received_by)
    values (sf.id, sf.student_id, p_amount, p_method, 'pending', my_teacher) returning id into new_id;

  if r = 'student' and p_method = 'cash' then
    return json_build_object('id', new_id, 'status', 'pending');
  end if;

  ok := (r = 'teacher' and p_method = 'cash') or random() > 0.1;   -- simulated gateway
  if ok then perform apply_payment(new_id, my_teacher);
  else update payments set status = 'failed' where id = new_id; end if;
  return json_build_object('id', new_id, 'status', case when ok then 'success' else 'failed' end);
end $$;

-- Teacher confirms (or declines) a pending cash payment
create or replace function confirm_cash_payment(p_payment_id uuid, p_ok boolean) returns void
language plpgsql security definer set search_path = public as $$
declare pay payments; sf student_fees; t uuid;
begin
  if my_role() not in ('teacher','admin') then raise exception 'Not allowed'; end if;
  select * into pay from payments where id = p_payment_id for update;
  if not found or pay.status <> 'pending' then raise exception 'Payment is not pending'; end if;
  select id into t from teachers where profile_id = auth.uid();
  if p_ok then
    select * into sf from student_fees where id = pay.student_fee_id;
    if pay.amount_paid > sf.amount_due - sf.amount_paid then raise exception 'Amount exceeds the remaining balance'; end if;
    perform apply_payment(p_payment_id, t);
  else
    update payments set status = 'failed', received_by = t where id = p_payment_id;
  end if;
end $$;

-- Admin corrects a payment record
create or replace function admin_set_payment_status(p_payment_id uuid, p_status text) returns void
language plpgsql security definer set search_path = public as $$
declare pay payments; paid numeric; due numeric;
begin
  if my_role() <> 'admin' then raise exception 'Admins only'; end if;
  if p_status not in ('success','failed') then raise exception 'Invalid status'; end if;
  select * into pay from payments where id = p_payment_id for update;
  if not found then raise exception 'Payment not found'; end if;
  if pay.status = p_status then return; end if;
  if p_status = 'success' then
    perform apply_payment(p_payment_id, null);
  else
    if pay.status = 'success' then
      update student_fees set amount_paid = amount_paid - pay.amount_paid
        where id = pay.student_fee_id returning amount_paid, amount_due into paid, due;
      update student_fees set status = case when paid >= due then 'paid' when paid > 0 then 'partial' else 'unpaid' end
        where id = pay.student_fee_id;
      delete from receipts where payment_id = p_payment_id;
    end if;
    update payments set status = 'failed' where id = p_payment_id;
  end if;
end $$;

-- Admin assigns a fee to all students (or only the fee's grade level)
create or replace function assign_fee(p_fee_id uuid) returns int
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if my_role() <> 'admin' then raise exception 'Admins only'; end if;
  insert into student_fees (student_id, fee_id, amount_due)
    select s.id, f.id, f.amount from students s, fees f
    where f.id = p_fee_id and (f.grade_level is null or f.grade_level = s.grade_level)
    on conflict (student_id, fee_id) do nothing;
  get diagnostics n = row_count;
  return n;
end $$;

-- Admin turns a registered user into a teacher
create or replace function make_teacher(p_email text, p_emp text, p_dept text) returns void
language plpgsql security definer set search_path = public as $$
declare pid uuid;
begin
  if my_role() <> 'admin' then raise exception 'Admins only'; end if;
  select id into pid from profiles where lower(email) = lower(p_email);
  if pid is null then raise exception 'No user with that email. Create the account in Supabase Auth first.'; end if;
  update profiles set role = 'teacher' where id = pid;
  insert into teachers (profile_id, employee_number, department) values (pid, p_emp, p_dept)
    on conflict (profile_id) do update set employee_number = excluded.employee_number, department = excluded.department;
end $$;

create or replace function remove_teacher(p_teacher_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare pid uuid;
begin
  if my_role() <> 'admin' then raise exception 'Admins only'; end if;
  select profile_id into pid from teachers where id = p_teacher_id;
  delete from teachers where id = p_teacher_id;
  update profiles set role = 'student' where id = pid;
end $$;

-- lock down who can call what
revoke all on function apply_payment(uuid, uuid) from public, anon, authenticated;
revoke all on function process_payment(uuid, numeric, text) from public, anon;
revoke all on function confirm_cash_payment(uuid, boolean) from public, anon;
revoke all on function admin_set_payment_status(uuid, text) from public, anon;
revoke all on function assign_fee(uuid) from public, anon;
revoke all on function make_teacher(text, text, text) from public, anon;
revoke all on function remove_teacher(uuid) from public, anon;
grant execute on function my_role() to authenticated;
grant execute on function process_payment(uuid, numeric, text) to authenticated;
grant execute on function confirm_cash_payment(uuid, boolean) to authenticated;
grant execute on function admin_set_payment_status(uuid, text) to authenticated;
grant execute on function assign_fee(uuid) to authenticated;
grant execute on function make_teacher(text, text, text) to authenticated;
grant execute on function remove_teacher(uuid) to authenticated;
