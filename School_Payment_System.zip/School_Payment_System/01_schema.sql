-- 01_schema.sql : tables, keys, indexes
create extension if not exists pgcrypto;

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'student' check (role in ('admin','student','teacher')),
  full_name text, email text, created_at timestamptz default now());

create table students (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid unique not null references profiles(id) on delete cascade,
  student_number text unique not null,
  grade_level text, section text, contact_number text, created_at timestamptz default now());

create table teachers (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid unique not null references profiles(id) on delete cascade,
  employee_number text unique not null,
  department text, created_at timestamptz default now());

create table fees (
  id uuid primary key default gen_random_uuid(),
  fee_name text not null, description text,
  amount numeric(10,2) not null check (amount > 0),
  due_date date, grade_level text, created_at timestamptz default now());

create table student_fees (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references students(id) on delete cascade,
  fee_id uuid not null references fees(id) on delete cascade,
  amount_due numeric(10,2) not null,
  amount_paid numeric(10,2) not null default 0,
  status text not null default 'unpaid' check (status in ('unpaid','partial','paid')),
  created_at timestamptz default now(),
  unique (student_id, fee_id));

create table payments (
  id uuid primary key default gen_random_uuid(),
  student_fee_id uuid not null references student_fees(id) on delete cascade,
  student_id uuid not null references students(id) on delete cascade,
  amount_paid numeric(10,2) not null check (amount_paid > 0),
  payment_method text not null check (payment_method in ('cash','card','online')),
  status text not null default 'pending' check (status in ('pending','success','failed')),
  received_by uuid references teachers(id) on delete set null,
  received_by_name text,
  payment_date timestamptz default now(), created_at timestamptz default now());

create table receipts (
  id uuid primary key default gen_random_uuid(),
  receipt_number text unique not null,
  payment_id uuid unique not null references payments(id) on delete cascade,
  issued_at timestamptz default now());

create index on student_fees(student_id);
create index on payments(student_id);
create index on payments(status);
create index on payments(student_fee_id);
