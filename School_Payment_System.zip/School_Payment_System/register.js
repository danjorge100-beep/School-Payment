$('f').addEventListener('submit', async e => {
  e.preventDefault(); hideMsg();
  const v = id => $(id).value.trim();
  if (!v('full_name') || !v('student_number') || !v('email')) return showMsg('error', 'Please fill in all fields.');
  if ($('password').value.length < 6) return showMsg('error', 'Password must be at least 6 characters.');
  $('btn').disabled = true;
  const { error } = await sb.auth.signUp({ email: v('email'), password: $('password').value,
    options: { data: { full_name: v('full_name'), student_number: v('student_number'), grade_level: v('grade_level'), section: v('section') } } });
  $('btn').disabled = false;
  if (error) return showMsg('error', 'Registration failed: ' + error.message + ' (the student number may already exist)');
  showMsg('success', 'Account created! You can now log in (check your email first if confirmation is enabled).');
  $('f').reset();
});
