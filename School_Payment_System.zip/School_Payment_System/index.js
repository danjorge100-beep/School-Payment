(async () => {
  const { data: { session } } = await sb.auth.getSession();
  if (session) { const { data: p } = await sb.from('profiles').select('role').eq('id', session.user.id).single(); if (p) location.href = HOME[p.role]; }
})();
$('f').addEventListener('submit', async e => {
  e.preventDefault(); hideMsg(); $('btn').disabled = true;
  const { data, error } = await sb.auth.signInWithPassword({ email: $('email').value.trim(), password: $('password').value });
  if (error) { showMsg('error', 'Invalid email or password.'); $('btn').disabled = false; return; }     // Display error message -> back to Log In
  const { data: p, error: e2 } = await sb.from('profiles').select('role').eq('id', data.user.id).single();
  if (e2 || !p) { showMsg('error', 'No profile found for this account.'); await sb.auth.signOut(); $('btn').disabled = false; return; }
  location.href = HOME[p.role];
});
