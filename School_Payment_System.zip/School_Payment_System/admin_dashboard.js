(async () => {
  if (!await requireRole('admin')) return;
  const cnt = async (t, f) => { let q = sb.from(t).select('id', { count: 'exact', head: true }); if (f) q = f(q); return (await q).count || 0; };
  $('cStu').textContent = await cnt('students'); $('cTea').textContent = await cnt('teachers');
  $('cPend').textContent = await cnt('payments', q => q.eq('status', 'pending'));
  const { data: pays } = await sb.from('payments').select('amount_paid').eq('status', 'success');
  $('cCol').textContent = money((pays || []).reduce((a, p) => a + Number(p.amount_paid), 0));
  const { data: sf } = await sb.from('student_fees').select('amount_due,amount_paid');
  $('cOut').textContent = money((sf || []).reduce((a, r) => a + Number(r.amount_due) - Number(r.amount_paid), 0));
  const { data, error } = await sb.from('payments').select(PAY_SELECT).order('created_at', { ascending: false }).limit(10);
  if (error) return showMsg('error', error.message);
  $('rows').innerHTML = payRowsHtml(data, true);
})();
