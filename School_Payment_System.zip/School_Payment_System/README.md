# School Payment System
HTML + CSS + vanilla JavaScript + Supabase. No build step.

Roles: **Student** (view fees, pay, receipts) · **Teacher** (cashier: search Student ID, receive payment, confirm cash) · **Admin** (students, teachers, fees, payment records, reports).

## 1. Supabase setup
1. Create a project at supabase.com.
2. SQL Editor: run in order `01_schema.sql`, `02_auth_hardening.sql`, `03_payment_functions.sql`, `04_seed_data.sql`, `05_rls_hardening.sql`.
3. Project Settings > API: copy the **Project URL** and **anon public key** into `supabase_client.js`. (Never use the service_role key.)
4. For easy testing: Authentication > Providers > Email > turn off "Confirm email".

## 2. Demo accounts
- Students: register on `register.html`.
- Admin/teachers: Authentication > Users > Add user (Auto Confirm), then:
  `update profiles set role = 'admin' where email = 'admin@school.test';`
- Log in as admin > **Teachers** to add teachers by email > **Fees** > "Assign to students".

## 3. Deploy on GitHub Pages
1. Push this folder to a GitHub repo (files in the repo root).
2. Settings > Pages > Deploy from branch > `main` / `/ (root)`.
3. Supabase > Authentication > URL Configuration: set Site URL and add a Redirect URL for `https://USERNAME.github.io/REPO/`.

## Notes
- Card/online payments are **simulated** (~90% succeed; no real gateway).
- Student cash payments stay *pending* until a teacher confirms them.
- All payment logic runs in SQL functions (`03_payment_functions.sql`); RLS (`05`) makes payments read-only from the browser.
