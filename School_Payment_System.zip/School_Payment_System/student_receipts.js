(async () => {
  if (!await requireRole('student')) return;
  const { data, error } = await sb.from('payments').select(PAY_SELECT).eq('status', 'success').order('created_at', { ascending: false });
  if (error) return showMsg('error', 'Unable to load receipts: ' + error.message);
  $('rows').innerHTML = payRowsHtml(data, false);
})();
