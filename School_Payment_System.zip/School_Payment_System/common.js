const HOME = { admin: 'admin_dashboard.html', teacher: 'teacher_dashboard.html', student: 'student_dashboard.html' };
const MENU = {
  student: [['Dashboard','student_dashboard.html'],['My Fees / Pay','student_fees.html'],['Payments','student_payments.html'],['Receipts','student_receipts.html']],
  teacher: [['Cashier','teacher_dashboard.html'],['Pending Cash','teacher_pending.html'],['Receipts','teacher_receipts.html']],
  admin:   [['Dashboard','admin_dashboard.html'],['Students','admin_students.html'],['Teachers','admin_teachers.html'],['Fees','admin_fees.html'],['Payments','admin_payments.html'],['Reports','admin_reports.html']]
};
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = n => '₱' + Number(n || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtDate = d => d ? new Date(d).toLocaleDateString() : '-';
const badge = s => `<span class="badge ${esc(s)}">${esc(s)}</span>`;
const $ = id => document.getElementById(id);

function showMsg(type, text) {              // type: success | error | info
  const el = $('msg'); if (!el) return alert(text);
  el.className = 'msg ' + type; el.textContent = text; el.style.display = 'block'; window.scrollTo(0, 0);
}
function hideMsg() { const el = $('msg'); if (el) el.style.display = 'none'; }

// Session + role check. Wrong role = sent to their own dashboard. (RLS is the real protection.)
async function requireRole(role) {
  const { data: { session } } = await sb.auth.getSession();
  if (!session) { location.href = 'index.html'; return null; }
  const { data: p, error } = await sb.from('profiles').select('*').eq('id', session.user.id).single();
  if (error || !p) { await sb.auth.signOut(); location.href = 'index.html'; return null; }
  if (p.role !== role) { location.href = HOME[p.role]; return null; }
  const nav = $('nav');
  nav.innerHTML = '<h2>🏫 School Payments</h2>' + MENU[role].map(([t, h]) =>
    `<a href="${h}" class="${location.pathname.endsWith(h) ? 'active' : ''}">${t}</a>`).join('') +
    '<button class="red" onclick="logout()">Log Out</button>';
  $('who').textContent = (p.full_name || p.email) + ' (' + role + ')';
  return p;
}
async function logout() { await sb.auth.signOut(); location.href = 'index.html'; }
