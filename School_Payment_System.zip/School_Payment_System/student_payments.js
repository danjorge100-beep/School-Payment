async function load() {
  let q = sb.from('payments').select(PAY_SELECT).order('created_at', { ascending: false });
  if ($('fStatus').value) q = q.eq('status', $('fStatus').value);
  const { data, error } = await q;
  if (error) return showMsg('error', 'Unable to load payments: ' + error.message);
  $('rows').innerHTML = payRowsHtml(data, false);
}
$('fStatus').onchange = load;
(async () => { if (await requireRole('student')) load(); })();
