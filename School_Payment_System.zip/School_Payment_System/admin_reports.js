let current = [];
async function generate() {
  hideMsg();
  let q = sb.from('payments').select(PAY_SELECT).order('payment_date', { ascending: false });
  if ($('from').value) q = q.gte('payment_date', $('from').value);
  if ($('to').value) q = q.lte('payment_date', $('to').value + 'T23:59:59');
  if ($('fStatus').value) q = q.eq('status', $('fStatus').value);
  const { data, error } = await q;
  if (error) return showMsg('error', 'Unable to generate report: ' + error.message);
  current = data; $('cCount').textContent = data.length;
  $('cSum').textContent = money(data.filter(p => p.status === 'success').reduce((a, p) => a + Number(p.amount_paid), 0));
  $('rows').innerHTML = payRowsHtml(data, true);
}
$('go').onclick = generate;
$('csv').onclick = () => {
  if (!current.length) return showMsg('error', 'Generate a report first.');
  const lines = [['Student No','Student','Fee','Amount','Method','Date','Status','Receipt']].concat(current.map(p => [p.students?.student_number, p.students?.profiles?.full_name, p.student_fees?.fees?.fee_name, p.amount_paid, p.payment_method, fmtDate(p.payment_date), p.status, one(p.receipts)?.receipt_number || '']));
  const csv = lines.map(r => r.map(c => '"' + String(c ?? '').replace(/"/g, '""') + '"').join(',')).join('\n');
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = 'payment_report.csv'; a.click();
};
(async () => { if (await requireRole('admin')) generate(); })();
