// Shared payment helpers: list rows, run a payment, show/print/email a receipt
const PAY_SELECT = '*, student_fees(fees(fee_name)), students(student_number, profiles(full_name,email)), receipts(receipt_number)';
const one = x => Array.isArray(x) ? x[0] : x;

function payRowsHtml(rows, showStudent, actionsFn) {
  if (!rows.length) return `<tr><td colspan="8">No payment records found.</td></tr>`;
  return rows.map(p => {
    const rc = one(p.receipts), st = p.students;
    return `<tr>
      ${showStudent ? `<td>${esc(st?.student_number)}<br><small>${esc(st?.profiles?.full_name)}</small></td>` : ''}
      <td>${esc(p.student_fees?.fees?.fee_name)}</td><td>${money(p.amount_paid)}</td>
      <td>${esc(p.payment_method)}</td><td>${fmtDate(p.payment_date)}</td><td>${badge(p.status)}</td>
      <td>${esc(rc?.receipt_number || '-')}</td>
      <td>${p.status === 'success' ? `<button onclick="showReceipt('${p.id}')">Receipt</button>` : ''} ${actionsFn ? actionsFn(p) : ''}</td></tr>`;
  }).join('');
}

// Student pays or teacher receives. Returns 'success' | 'failed' | 'pending' | null (error)
async function doPayment(feeId, amount, method, balance) {
  amount = Number(amount);
  if (!feeId) { showMsg('error', 'Please select a fee.'); return null; }
  if (!(amount > 0)) { showMsg('error', 'Amount must be greater than 0.'); return null; }
  if (amount > balance) { showMsg('error', 'Amount cannot exceed the remaining balance.'); return null; }
  showMsg('info', 'Awaiting payment...');
  const { data, error } = await sb.rpc('process_payment', { p_student_fee_id: feeId, p_amount: amount, p_method: method });
  if (error) { showMsg('error', 'Unable to process payment: ' + error.message); return null; }
  if (data.status === 'success') { showMsg('success', 'Payment successful! Receipt generated.'); showReceipt(data.id); }
  else if (data.status === 'pending') showMsg('info', 'Cash payment recorded. Waiting for a teacher to confirm it.');
  else showMsg('error', 'Payment Failed. Please try again.');
  return data.status;
}

async function showReceipt(paymentId) {
  const { data: p, error } = await sb.from('payments').select(PAY_SELECT).eq('id', paymentId).single();
  if (error) return showMsg('error', 'Unable to load receipt: ' + error.message);
  const rc = one(p.receipts), st = p.students;
  let m = $('receiptModal'); if (!m) { m = document.createElement('div'); m.id = 'receiptModal'; document.body.appendChild(m); }
  m.style.display = 'flex';
  m.innerHTML = `<div class="receipt"><h3>SCHOOL PAYMENT SYSTEM</h3><p>Receipt No: <b>${esc(rc?.receipt_number)}</b></p>
    <p>Date: ${fmtDate(p.payment_date)}</p><hr>
    <p>Student: ${esc(st?.profiles?.full_name)}</p><p>Student No: ${esc(st?.student_number)}</p><hr>
    <p>Fee: ${esc(p.student_fees?.fees?.fee_name)}</p><p>Amount: ${money(p.amount_paid)}</p>
    <p>Method: ${esc(p.payment_method)}</p><p>Status: ${esc(p.status).toUpperCase()}</p>
    <p>Received by: ${esc(p.received_by_name || 'System')}</p><hr><p style="text-align:center">Thank you.</p>
    <div class="no-print" style="display:flex;gap:6px;margin-top:10px">
      <button onclick="printReceipt()">Print</button>
      <button class="green" id="emailBtn">Email</button>
      <button class="gray" onclick="$('receiptModal').style.display='none'">Close</button></div></div>`;
  $('emailBtn').onclick = () => {
    const body = `Receipt ${rc?.receipt_number}%0AFee: ${p.student_fees?.fees?.fee_name}%0AAmount: ${p.amount_paid}%0AMethod: ${p.payment_method}`;
    location.href = `mailto:${st?.profiles?.email || ''}?subject=${encodeURIComponent('Payment Receipt ' + (rc?.receipt_number || ''))}&body=${body}`;
  };
}
function printReceipt() { document.body.classList.add('print-receipt'); window.print(); document.body.classList.remove('print-receipt'); }
