-- 05_rls_hardening.sql : Row Level Security (the real protection; JavaScript checks are only for UX)
alter table profiles     enable row level security;
alter table students     enable row level security;
alter table teachers     enable row level security;
alter table fees         enable row level security;
alter table student_fees enable row level security;
alter table payments     enable row level security;
alter table receipts     enable row level security;

-- profiles: read own, staff read all, ONLY admin can change (blocks role self-promotion)
create policy profiles_select on profiles for select using (id = auth.uid() or my_role() in ('admin','teacher'));
create policy profiles_admin  on profiles for all using (my_role() = 'admin') with check (my_role() = 'admin');

create policy students_select on students for select using (profile_id = auth.uid() or my_role() in ('admin','teacher'));
create policy students_admin  on students for all using (my_role() = 'admin') with check (my_role() = 'admin');

create policy teachers_select on teachers for select using (profile_id = auth.uid() or my_role() = 'admin');
create policy teachers_admin  on teachers for all using (my_role() = 'admin') with check (my_role() = 'admin');

create policy fees_select on fees for select using (auth.uid() is not null);
create policy fees_admin  on fees for all using (my_role() = 'admin') with check (my_role() = 'admin');

create policy sfees_select on student_fees for select using (
  student_id in (select id from students where profile_id = auth.uid()) or my_role() in ('admin','teacher'));
create policy sfees_admin on student_fees for all using (my_role() = 'admin') with check (my_role() = 'admin');

-- payments & receipts: read-only from the browser. All writes go through the functions in 03.
create policy payments_select on payments for select using (
  student_id in (select id from students where profile_id = auth.uid()) or my_role() in ('admin','teacher'));
create policy receipts_select on receipts for select using (exists (select 1 from payments p where p.id = payment_id));
