async function load() {
  let q = sb.from('payments').select(PAY_SELECT).order('created_at', { ascending: false });
  if ($('fStatus').value) q = q.eq('status', $('fStatus').value);
  const { data, error } = await q;
  if (error) return showMsg('error', 'Unable to load payments: ' + error.message);
  $('rows').innerHTML = payRowsHtml(data, true, p => `${p.status !== 'success' ? `<button class="green" onclick="setStatus('${p.id}','success')">Mark success</button>` : ''} ${p.status !== 'failed' ? `<button class="red" onclick="setStatus('${p.id}','failed')">Mark failed</button>` : ''}`);
}
async function setStatus(id, status) {
  if (!confirm('Change this payment to ' + status + '?')) return;
  const { error } = await sb.rpc('admin_set_payment_status', { p_payment_id: id, p_status: status });
  if (error) return showMsg('error', 'Unable to update: ' + error.message); showMsg('success', 'Payment record updated.'); load();
}
$('fStatus').onchange = load;
(async () => { if (await requireRole('admin')) load(); })();
