let list = [];
async function load() {
  const { data, error } = await sb.from('students').select('*, profiles(full_name,email)').order('student_number');
  if (error) return showMsg('error', 'Unable to load students: ' + error.message);
  list = data; draw();
}
function draw() {
  const q = $('search').value.toLowerCase();
  const rows = list.filter(s => (s.student_number + ' ' + s.profiles?.full_name).toLowerCase().includes(q));
  $('rows').innerHTML = rows.length ? rows.map(s => `<tr><td>${esc(s.student_number)}</td><td>${esc(s.profiles?.full_name)}</td><td>${esc(s.profiles?.email)}</td><td>${esc(s.grade_level)}</td><td>${esc(s.section)}</td><td>${esc(s.contact_number)}</td>
    <td><button onclick="edit('${s.id}')">Edit</button> <button class="red" onclick="del('${s.id}')">Delete</button></td></tr>`).join('') : '<tr><td colspan="7">No students found.</td></tr>';
}
function edit(id) { const s = list.find(x => x.id === id);
  $('id').value = s.id; $('pid').value = s.profile_id; $('full_name').value = s.profiles?.full_name || ''; $('student_number').value = s.student_number;
  $('grade_level').value = s.grade_level || ''; $('section').value = s.section || ''; $('contact_number').value = s.contact_number || ''; window.scrollTo(0, 0); }
async function del(id) {
  if (!confirm('Delete this student and all their fees and payments?')) return;
  const { error } = await sb.from('students').delete().eq('id', id);
  if (error) return showMsg('error', 'Unable to delete: ' + error.message); showMsg('success', 'Student deleted.'); load();
}
$('f').addEventListener('submit', async e => {
  e.preventDefault(); hideMsg(); if (!$('id').value) return showMsg('error', 'Click Edit on a student first.');
  const a = await sb.from('students').update({ student_number: $('student_number').value.trim(), grade_level: $('grade_level').value.trim(), section: $('section').value.trim(), contact_number: $('contact_number').value.trim() }).eq('id', $('id').value);
  const b = await sb.from('profiles').update({ full_name: $('full_name').value.trim() }).eq('id', $('pid').value);
  if (a.error || b.error) return showMsg('error', 'Unable to save: ' + (a.error || b.error).message);
  showMsg('success', 'Student updated.'); $('f').reset(); load();
});
$('search').oninput = draw;
(async () => { if (await requireRole('admin')) load(); })();
