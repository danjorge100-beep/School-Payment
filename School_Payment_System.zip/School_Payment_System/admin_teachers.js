async function load() {
  const { data, error } = await sb.from('teachers').select('*').order('employee_number');
  if (error) return showMsg('error', 'Unable to load teachers: ' + error.message);
  const { data: profs } = await sb.from('profiles').select('id,full_name,email').eq('role', 'teacher');
  const pm = Object.fromEntries((profs || []).map(p => [p.id, p]));
  $('rows').innerHTML = data.length ? data.map(t => `<tr><td>${esc(t.employee_number)}</td><td>${esc(pm[t.profile_id]?.full_name)}</td><td>${esc(pm[t.profile_id]?.email)}</td><td>${esc(t.department)}</td>
    <td><button class="red" onclick="del('${t.id}')">Remove</button></td></tr>`).join('') : '<tr><td colspan="5">No teachers yet.</td></tr>';
}
async function del(id) {
  if (!confirm('Remove this teacher?')) return;
  const { error } = await sb.rpc('remove_teacher', { p_teacher_id: id });
  if (error) return showMsg('error', 'Unable to remove: ' + error.message); showMsg('success', 'Teacher removed.'); load();
}
$('f').addEventListener('submit', async e => {
  e.preventDefault(); hideMsg();
  const { error } = await sb.rpc('make_teacher', { p_email: $('email').value.trim(), p_emp: $('emp').value.trim(), p_dept: $('dept').value.trim() });
  if (error) return showMsg('error', 'Unable to save teacher: ' + error.message);
  showMsg('success', 'Teacher saved.'); $('f').reset(); load();
});
(async () => { if (await requireRole('admin')) load(); })();
