-- 04_seed_data.sql : sample fees + how to create demo users
-- Run this AFTER 01-03. Passwords are never stored in SQL.

insert into fees (fee_name, description, amount, due_date, grade_level) values
  ('Tuition Fee',      'Yearly tuition',        15000, current_date + 30, null),
  ('Registration Fee', 'Enrollment fee',         2000, current_date + 15, null),
  ('Laboratory Fee',   'Science lab use',        1500, current_date + 45, null),
  ('Library Fee',      'Library membership',      500, current_date + 60, null);

-- DEMO USERS (do this in the Supabase dashboard, not SQL):
-- 1) Authentication > Users > Add user  (tick "Auto Confirm User")
--      admin@school.test, teacher1@school.test, teacher2@school.test
--    Students: use register.html (5 accounts).
-- 2) Make the first admin (replace the email):
--      update profiles set role = 'admin' where email = 'admin@school.test';
-- 3) Log in as admin > Teachers page > add each teacher by email.
-- 4) Admin > Fees > click "Assign to students" on each fee.
