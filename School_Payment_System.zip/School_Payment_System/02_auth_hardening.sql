-- 02_auth_hardening.sql : every new signup becomes a STUDENT (role can never come from the browser)
create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, role, full_name, email)
  values (new.id, 'student', coalesce(new.raw_user_meta_data->>'full_name',''), new.email);

  insert into students (profile_id, student_number, grade_level, section)
  values (new.id,
    coalesce(nullif(new.raw_user_meta_data->>'student_number',''), 'S-' || substr(new.id::text,1,8)),
    new.raw_user_meta_data->>'grade_level',
    new.raw_user_meta_data->>'section');
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();
