async function load() {
  const { data, error } = await sb.from('payments').select(PAY_SELECT).eq('status', 'pending').order('created_at');
  if (error) return showMsg('error', 'Unable to load payments: ' + error.message);
  $('rows').innerHTML = payRowsHtml(data, true, p => `<button class="green" onclick="decide('${p.id}',true)">Confirm</button> <button class="red" onclick="decide('${p.id}',false)">Decline</button>`);
}
async function decide(id, ok) {
  if (!ok && !confirm('Decline this payment?')) return;
  const { error } = await sb.rpc('confirm_cash_payment', { p_payment_id: id, p_ok: ok });
  if (error) return showMsg('error', 'Unable to update payment: ' + error.message);
  showMsg('success', ok ? 'Payment confirmed. Receipt generated.' : 'Payment declined.'); load();
}
(async () => { if (await requireRole('teacher')) load(); })();
