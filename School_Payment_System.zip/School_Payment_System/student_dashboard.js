(async () => {
  if (!await requireRole('student')) return;
  const { data, error } = await sb.from('student_fees').select('*, fees(fee_name,due_date)').order('created_at');
  if (error) return showMsg('error', 'Unable to load fees: ' + error.message);
  const { count } = await sb.from('payments').select('id', { count: 'exact', head: true }).eq('status', 'pending');
  const sum = k => data.reduce((a, r) => a + Number(r[k]), 0);
  $('cTotal').textContent = money(sum('amount_due')); $('cPaid').textContent = money(sum('amount_paid'));
  $('cBal').textContent = money(sum('amount_due') - sum('amount_paid')); $('cPend').textContent = count || 0;
  $('rows').innerHTML = data.length ? data.map(r => `<tr><td>${esc(r.fees.fee_name)}</td><td>${fmtDate(r.fees.due_date)}</td><td>${money(r.amount_due)}</td><td>${money(r.amount_paid)}</td><td>${money(r.amount_due - r.amount_paid)}</td><td>${badge(r.status)}</td></tr>`).join('') : '<tr><td colspan="6">No fees assigned yet.</td></tr>';
})();
