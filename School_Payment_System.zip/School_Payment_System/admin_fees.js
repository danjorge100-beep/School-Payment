let list = [];
async function load() {
  const { data, error } = await sb.from('fees').select('*').order('created_at');
  if (error) return showMsg('error', 'Unable to load fees: ' + error.message);
  list = data;
  $('rows').innerHTML = data.length ? data.map(f => `<tr><td>${esc(f.fee_name)}</td><td>${money(f.amount)}</td><td>${fmtDate(f.due_date)}</td><td>${esc(f.grade_level || 'All')}</td>
    <td><button class="green" onclick="assign('${f.id}')">Assign to students</button> <button onclick="edit('${f.id}')">Edit</button> <button class="red" onclick="del('${f.id}')">Delete</button></td></tr>`).join('') : '<tr><td colspan="5">No fees yet.</td></tr>';
}
function edit(id) { const f = list.find(x => x.id === id); $('ft').textContent = 'Edit fee';
  ['id','fee_name','amount','due_date','grade_level','description'].forEach(k => $(k).value = f[k] || ''); window.scrollTo(0, 0); }
async function assign(id) {
  const { data, error } = await sb.rpc('assign_fee', { p_fee_id: id });
  if (error) return showMsg('error', 'Unable to assign: ' + error.message); showMsg('success', data + ' student(s) assigned.');
}
async function del(id) {
  if (!confirm('Delete this fee and every student record for it?')) return;
  const { error } = await sb.from('fees').delete().eq('id', id);
  if (error) return showMsg('error', 'Unable to delete: ' + error.message); showMsg('success', 'Fee deleted.'); load();
}
$('f').addEventListener('submit', async e => {
  e.preventDefault(); hideMsg();
  const row = { fee_name: $('fee_name').value.trim(), amount: Number($('amount').value), due_date: $('due_date').value || null, grade_level: $('grade_level').value.trim() || null, description: $('description').value.trim() };
  if (!row.fee_name || !(row.amount > 0)) return showMsg('error', 'Fee name and a positive amount are required.');
  const id = $('id').value;
  const { error } = id ? await sb.from('fees').update(row).eq('id', id) : await sb.from('fees').insert(row);
  if (error) return showMsg('error', 'Unable to save fee: ' + error.message);
  showMsg('success', 'Fee saved.'); $('f').reset(); $('id').value = ''; $('ft').textContent = 'Create fee'; load();
});
(async () => { if (await requireRole('admin')) load(); })();
