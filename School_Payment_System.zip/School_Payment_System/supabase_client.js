// Paste your Supabase Project URL and ANON (public) key. NEVER put the service_role key here.
const SUPABASE_URL = 'https://YOUR-PROJECT.supabase.co';
const SUPABASE_ANON_KEY = 'YOUR-ANON-KEY';
const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
