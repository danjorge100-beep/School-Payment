let student = null, feesData = [];
async function loadFees() {           // Display Student Fees
  const { data, error } = await sb.from('student_fees').select('*, fees(fee_name)').eq('student_id', student.id).order('created_at');
  if (error) return showMsg('error', 'Unable to load fees: ' + error.message);
  feesData = data;
  $('rows').innerHTML = data.length ? data.map(r => { const bal = r.amount_due - r.amount_paid;
    return `<tr><td>${esc(r.fees.fee_name)}</td><td>${money(r.amount_due)}</td><td>${money(r.amount_paid)}</td><td>${money(bal)}</td><td>${badge(r.status)}</td>
    <td>${bal > 0 ? `<button onclick="pick('${r.id}')">Receive</button>` : ''}</td></tr>`; }).join('') : '<tr><td colspan="6">No fees for this student.</td></tr>';
}
$('find').onclick = async () => {
  hideMsg(); const v = $('sid').value.trim(); if (!v) return showMsg('error', 'Please enter a Student ID.');
  const { data, error } = await sb.from('students').select('*, profiles(full_name)').eq('student_number', v).maybeSingle();
  if (error) return showMsg('error', error.message);
  if (!data) { $('result').style.display = 'none'; return showMsg('error', 'Student not found.'); }
  student = data; $('sname').textContent = data.profiles.full_name + ' (' + data.student_number + ') - ' + (data.grade_level || '') + ' ' + (data.section || '');
  $('result').style.display = 'block'; loadFees();
};

let selected = null;
function pick(id) { selected = feesData.find(f => f.id === id); $('feeName').value = selected.fees.fee_name;
  selected.bal = selected.amount_due - selected.amount_paid; $('balance').value = money(selected.bal); $('amount').value = selected.bal; $('amount').focus(); }
$('payBtn').addEventListener('click', async () => {
  hideMsg(); if (!selected) return showMsg('error', 'Please select a fee first.');
  $('payBtn').disabled = true;                                   // prevents double submit
  const status = await doPayment(selected.id, $('amount').value, $('method').value, selected.bal);
  $('payBtn').disabled = false;
  if (status) { selected = null; $('feeName').value = ''; $('balance').value = ''; $('amount').value = ''; }
  loadFees();
});

(async () => { await requireRole('teacher'); })();
