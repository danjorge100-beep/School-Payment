let feesData = [];
async function loadFees() {
  const { data, error } = await sb.from('student_fees').select('*, fees(fee_name,due_date)').order('created_at');
  if (error) return showMsg('error', 'Unable to load fees: ' + error.message);
  feesData = data;
  $('rows').innerHTML = data.length ? data.map(r => { const bal = r.amount_due - r.amount_paid;
    return `<tr><td>${esc(r.fees.fee_name)}</td><td>${fmtDate(r.fees.due_date)}</td><td>${money(r.amount_due)}</td><td>${money(r.amount_paid)}</td><td>${money(bal)}</td><td>${badge(r.status)}</td>
    <td>${bal > 0 ? `<button onclick="pick('${r.id}')">Pay</button>` : ''}</td></tr>`; }).join('') : '<tr><td colspan="7">No fees assigned yet.</td></tr>';
}

let selected = null;
function pick(id) { selected = feesData.find(f => f.id === id); $('feeName').value = selected.fees.fee_name;
  selected.bal = selected.amount_due - selected.amount_paid; $('balance').value = money(selected.bal); $('amount').value = selected.bal; $('amount').focus(); }
$('payBtn').addEventListener('click', async () => {
  hideMsg(); if (!selected) return showMsg('error', 'Please select a fee first.');
  $('payBtn').disabled = true;                                   // prevents double submit
  const status = await doPayment(selected.id, $('amount').value, $('method').value, selected.bal);
  $('payBtn').disabled = false;
  if (status) { selected = null; $('feeName').value = ''; $('balance').value = ''; $('amount').value = ''; }
  loadFees();
});

(async () => { if (await requireRole('student')) loadFees(); })();
